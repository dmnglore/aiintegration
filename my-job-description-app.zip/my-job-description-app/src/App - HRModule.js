import React, { useState } from 'react';
import './common.css';

function JobDescriptionGenerator() {
  const [inputText, setInputText] = useState('');
  const [otherText, setOtherText] = useState('');
  const [location, setLocation] = useState('');
  const [experience, setExperience] = useState('');
  const [salaryRange, setSalaryRange] = useState('');
  const [emailId, setEmailId] = useState('');
  const [response, setResponse] = useState('');

  const generateResponse = () => {
    const text = 'Generate a comprehensive job description for the position of, ';
    const generatedText = `${text}${inputText} outlining the responsibilities, for a ${otherText}, ${location} and Minimum Experience ${experience}. Please share your resume to ${emailId}. Salary range is ${salaryRange}`;

    // You can use the 'fetch' API to make a POST request to your server.
    // Replace '/generateResponse' with your actual API endpoint.
    //fetch('/generateResponse', {
      fetch('http://localhost:8092/generateResponse', {
            method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ inputText: generatedText }),
      //mode: 'no-cors', // Use with caution and only for testing
    })
      .then((response) => response.json())
      .then((data) => {
        setResponse(data.response);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  return (
    <div className="container">
      <h4 className="form-heading">Job Description Generator</h4>

      <label htmlFor="jobTitle">Enter Job Title (Avoid using special characters like (%# etc...</label>
      <textarea
        id="inputText"
        className="form-control"
        autoFocus={true}
        rows="1"
        cols="80"
        placeholder="Java Architect"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
      ></textarea>
      

      <label htmlFor="otherText">Things to make sure are included/emphasized (use comma separated for more keywords)</label>
      <textarea
        id="otherText"
        className="form-control"
        rows="1"
        cols="80"
        autoFocus={true}
        placeholder="Banking Domain/Financial Domain"
        value={otherText}
        onChange={(e) => setOtherText(e.target.value)}
      ></textarea>
      

      <label htmlFor="Location">Location</label>
      <textarea
        id="location"
        className="form-control"
        rows="1"
        cols="80"
        autoFocus={true}
        placeholder="Location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
      ></textarea>
      

      <label htmlFor="experience">Minimum Experience (in years)</label>
      <textarea
        id="experience"
        className="form-control"
        rows="1"
        cols="80"
        autoFocus={true}
        placeholder="Minimum Experience"
        value={experience}
        onChange={(e) => setExperience(e.target.value)}
      ></textarea>
      

      <label htmlFor="salaryRange">Salary Range</label>
      <textarea
        id="salaryRange"
        className="form-control"
        rows="1"
        cols="80"
        placeholder="0-0"
        autoFocus={true}
        value={salaryRange}
        onChange={(e) => setSalaryRange(e.target.value)}
      ></textarea>
      

      <label htmlFor="emailId">Enter Hiring Manager EmailId</label>
      <textarea
        id="emailId"
        className="form-control"
        rows="1"
        cols="80"
        placeholder="test@test.com"
        autoFocus={true}
        value={emailId}
        onChange={(e) => setEmailId(e.target.value)}
      ></textarea>
      <br />
      

      <button onClick={generateResponse}>Generate Response</button>
      <br />

      <label htmlFor="responseText">Job Description from ChatGPT</label>
      <textarea
        id="responseText"
        className="form-control"
        rows="5"
        cols="80"
        autoFocus={true}
        readOnly
        value={response}
      ></textarea>
      <br />
      

      <button onClick={generateResponse} disabled >Send Email</button>&nbsp;
      <button onClick={generateResponse}>Regenerate</button>&nbsp;
      <button onClick={() => { /* Handle cancel action */ }}>Review</button>
    </div>
  );
}

export default JobDescriptionGenerator;
