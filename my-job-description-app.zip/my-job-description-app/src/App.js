import React, { useState } from 'react';
import './common.css';

function JobDescriptionGenerator() {
  const [inputText, setInputText] = useState('');
  //const [otherText, setOtherText] = useState('');
  //const [location, setLocation] = useState('');
  //const [experience, setExperience] = useState('');
  //const [salaryRange, setSalaryRange] = useState('');
  //const [emailId, setEmailId] = useState('');
  const [response, setResponse] = useState('');

  const generateResponse = () => {
    //const text = 'Generate a comprehensive job description for the position of, ';
    //const generatedText = `${text}${inputText} outlining the responsibilities, for a ${otherText}, ${location} and Minimum Experience ${experience}. Please share your resume to ${emailId}. Salary range is ${salaryRange}`;
    const generatedText = `${inputText} `;

    // You can use the 'fetch' API to make a POST request to your server.
    // Replace '/generateResponse' with your actual API endpoint.
    //fetch('/generateResponse', {
      fetch('http://localhost:8092/generateResponse', {
            method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ inputText: generatedText }),
      //mode: 'no-cors', // Use with caution and only for testing
    })
      .then((response) => response.json())
      .then((data) => {
        setResponse(data.response);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  return (
    <div className="container ">
      <h4 className="form-heading has-error centered-button-container">AI IN AGILE WORKFLOW</h4>

      <label htmlFor="jobTitle">ENTER EPIC DETAILS(Avoid using special characters like (%# etc...</label>
      <textarea
        id="inputText"
        className="form-control"
        autoFocus={true}
        rows="1"
        cols="80"
        placeholder=""
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
      ></textarea>
           
      <br />
      
      
      <button onClick={generateResponse}>Generate Response</button>
        <br />


      <label htmlFor="responseText">Response from AI</label>
      <textarea
        id="responseText"
        className="form-control"
        rows="5"
        cols="80"
        autoFocus={true}
        readOnly
        value={response}
      ></textarea>
      <br />
      

      <button onClick={generateResponse} disabled >Send Email</button>&nbsp;
      <button onClick={generateResponse}>Regenerate</button>&nbsp;
      <button onClick={() => { /* Handle cancel action */ }}>Review</button>
    </div>
  );
}

export default JobDescriptionGenerator;
