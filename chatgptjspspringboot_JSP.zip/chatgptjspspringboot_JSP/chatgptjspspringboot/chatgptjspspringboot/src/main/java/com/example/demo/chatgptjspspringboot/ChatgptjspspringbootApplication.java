package com.example.demo.chatgptjspspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatgptjspspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatgptjspspringbootApplication.class, args);
	}

}
