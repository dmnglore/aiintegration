package com.example.demo.chatgptjspspringboot.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.chatgptjspspringboot.model.BotRequest;
import com.example.demo.chatgptjspspringboot.model.BotResponse;

import lombok.Value;


@Controller
public class JspController {
	
	//@Value("${openai.model}")
	  private String model;

	  //@Value("${openai.api.url}")
	  private String apiUrl;
	
	 @Autowired
	  private RestTemplate restTemplate;

	  
	
		/*
		 * @RequestMapping("/") public String chatPage() {
		 * System.out.println("This is home"); return "chat"; }
		 */
	 @GetMapping("/")
	    public String chatPage() {
	        return "chat";
	    }
	
	
	@PostMapping("/generateResponse")
    @ResponseBody
    public Map<String, String> generateResponse(@RequestBody Map<String, String> request) {
        String inputText = request.get("inputText");
        String response = generateChatGPTResponse(inputText);

        Map<String, String> responseMap = new HashMap<>();
        responseMap.put("response", response);
        return responseMap;
    }
	
	private String generateChatGPTResponse(String inputText) {
        // Replace this with your actual ChatGPT API integration code
        // Here, you would call the API and get the response
        // For simplicity, we'll return a mock response
		
		BotResponse botResponse = chat(inputText);
		System.out.println(botResponse);
		String content = botResponse.getChoices().get(0).getMessage().getContent();
		System.out.println("$$$$$$$$$$$$$$$$$$$"+content);

		
        return content;
    }
	
	  @PostMapping("/chat")
	  public BotResponse chat(String prompt) {
		  model = "gpt-3.5-turbo-0613";
		  apiUrl = "https://api.openai.com/v1/chat/completions";
		  //prompt="what is springboot";
	    BotRequest request = new BotRequest(model,prompt);
	    System.out.println(request.toString());

	    BotResponse botResponse = restTemplate.postForObject(apiUrl, request, BotResponse.class);
	    System.out.println(botResponse.toString());

	    return botResponse;
	  }
	
	

}
