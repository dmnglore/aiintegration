/*
 * package com.example.demo.chatgptjspspringboot;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class ChatgptjspspringbootApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */